<?php
  // $conn = mysqli_connect("localhost", "root", "", "komis1");
  $conn = mysqli_connect("localhost", "zuzanna", "zaq1@WSX", "komis1");
  mysqli_set_charset($conn, "utf8");
 ?>
