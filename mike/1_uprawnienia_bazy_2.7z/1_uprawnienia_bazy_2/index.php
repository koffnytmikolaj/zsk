<!DOCTYPE html>
<html lang="pl" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="./css/style.css">
    <title>Bazy - uprawnienia</title>
  </head>
  <body>
    <?php
      require_once("./connect.php");

      //$sql = "select * from user";
      $sql = "select id, name, surname, birthday from user";

      if ($result = mysqli_query($conn, $sql)) {
        //echo "prawidłowe zapytanie";
        mysqli_close($conn);

      echo <<<TABLE
      <table>
        <tr>
          <th>Imię</th>
          <th>Nazwisko</th>
          <th>Data urodzenia</th>
          <th>Rok urodzenia</th>
          <th>Usuń użytkownika</th>
        </tr>
TABLE;

      while ($row = mysqli_fetch_assoc($result)) {
        $year = substr($row['birthday'],0,4);
        echo <<<ROW
        <tr>
          <td>$row[name]</td>
          <td>$row[surname]</td>
          <td>$row[birthday]</td>
          <td>$year</td>
          <td><a href="./scripts/delete_user.php?id=$row[id]">Usuń</a></td>
        </tr>
ROW;
      }
      echo "</table>";

      


      }else {
        echo "błędne zapytanie";
      }
     ?>
  </body>
</html>
