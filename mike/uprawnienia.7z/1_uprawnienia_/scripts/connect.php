<?php
  $conn = mysqli_connect("localhost", "root", "", "komis");
  //$conn = mysqli_connect("localhost", "katarzyna", "zaq1@WSX", "komis");
  mysqli_set_charset($conn, "utf8");
 ?>
