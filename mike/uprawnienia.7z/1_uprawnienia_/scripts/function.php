<?php
  function year($x){
    return substr($x, 0, 4);
  }
 ?>
